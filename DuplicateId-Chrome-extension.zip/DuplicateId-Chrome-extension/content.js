// content.js
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "getInputNames") {
    const inputNames = [];
    const inputNamess = [];
    const inputNamessplus = [];
    
    $("form:first input[name]").each(function() {

      var name = $('[name="'+this.name+'"]');

      if(name.length>1 && name[0]==this) {
        inputNames.push($(this).attr("name"));
      }
    });

    $('form').find('select option').each(function() {
         
      var value = $(this).val();
      if (value.includes('&')) {
        inputNamess.push(value);
      }

      if (value.includes('+')) {
        inputNamessplus.push(value);
      }

  });
    
    sendResponse({inputNames,inputNamess,inputNamessplus});
  }
});
