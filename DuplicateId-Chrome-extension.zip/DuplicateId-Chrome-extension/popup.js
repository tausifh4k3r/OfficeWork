// popup.js
chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  chrome.tabs.sendMessage(tabs[0].id, { action: "getInputNames" }, function (response) {
    // const inputNamesElement = $("#inputNames");
    
    if (response && response.inputNames && response.inputNames.length > 0) {
      const inputNamesList = response.inputNames.map(name => `<li>${name}</li>`).join("");
      $("#inputNames").html(`<ul style='color:red;font-weight:800;'>${inputNamesList}</ul>`);
      // alert(inputNamesList);
    } else {
      $("#inputNames").text("No input names found in the form on this page.");
    }


    if (response && response.inputNamess && response.inputNamess.length > 0) {
      const inputNamesLists = response.inputNamess.map(name => `<li>${name}</li>`).join("");
      $("#inputNamess").html(`<ul style='color:red;font-weight:800;'>${inputNamesLists}</ul>`);
      // alert(inputNamesList);
    } else {
      $("#inputNamess").text("No & names found in the form on this page.");
    }


    if (response && response.inputNamessplus && response.inputNamessplus.length > 0) {
      const inputNamesListsplus = response.inputNamessplus.map(name => `<li>${name}</li>`).join("");
      $("#inputNamessplus").html(`<ul style='color:red;font-weight:800;'>${inputNamesListsplus}</ul>`);
      // alert(inputNamesList);
    } else {
      $("#inputNamessplus").text("No + found in the form on this page.");
    }



  });
});
